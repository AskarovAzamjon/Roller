package com.example.roller

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.roller.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.buttonOne.setOnClickListener {
            rollDice()
        }


    }

    private fun rollDice() {
        val dice = Dice(6)
        val dr = when (dice.diceRoll()) {
            1 -> R.drawable.one3d
            2 -> R.drawable.two3d
            3 -> R.drawable.three3d
            4 -> R.drawable.four3d
            5 -> R.drawable.five3d
            else -> R.drawable.six3d
        }
        binding.imageView.setImageResource(dr)

    }
}

class Dice(private val numSize: Int) {

    fun diceRoll(): Int {

        return (1..numSize).random()
    }
}